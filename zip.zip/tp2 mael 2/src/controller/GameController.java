package controller;

import javafx.scene.canvas.GraphicsContext;
import model.Game;
import model.Platform;
import view.GameView;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

public class GameController
{

    // Attributes
    private GameView gameView;
    private Game game;
    private boolean debug;
    private ScheduledExecutorService thread;

    // Constructor
    public GameController()
    {
        Game.isStarted = false;
        this.gameView = new GameView();
        this.game = new Game();
        this.registerEvent(); // Register key pressed event
        this.debug = false;
    }

    public void setThread(ScheduledExecutorService e) { this.thread = e; }

    // Updates all
    public void update(double time)
    {
        this.game.updateBubbles(time, this.gameView.getOffsetY());
        if(Game.isStarted)
        {
            this.gameView.update(time, this.game.getPlayer());
            this.game.update(time, this.gameView.getOffsetY(), this.gameView);
        }
    }

    // Draws all
    public void draw(GraphicsContext context, double offsetY)
    {
        this.gameView.draw();
        this.game.draw(context, offsetY);
        this.game.drawBubbles(context, offsetY);
    }

    // TODO:explain
    public void debug()
    {
        if(debug)
        {
            // Turn off debug
            this.gameView.setDebug(false);
            this.game.getPlayer().setDebug(false);
            this.game.setDebug(false);
            for(Platform p : this.game.getPlatforms())
                p.setDebug(false);
            this.debug = false;
        }
        else
        {
            // Turn on debug
            this.gameView.setDebug(true);
            this.game.getPlayer().setDebug(true);
            this.game.setDebug(true);
            for(Platform p : this.game.getPlatforms())
                p.setDebug(true);
            this.debug = true;
        }
    }

    // What happens when user presses certain keys
    public void registerEvent()
    {
        this.gameView.getScene().setOnKeyPressed(e -> {
                switch(e.getCode())
                {
                    case LEFT:  // Left arrow is pressed
                        if(!Game.isStarted) Game.isStarted = true;
                        this.game.getPlayer().setLeft(true);
                        break;
                    case RIGHT: // Right arrow is pressed
                        if(!Game.isStarted) Game.isStarted = true;
                        this.game.getPlayer().setRight(true);
                        break;
                    case SPACE: // Space key is pressed
                        if(!Game.isStarted)
                         {
                            this.game.getPlayer().onGround(true);
                            Game.isStarted = true;
                        }
                        this.game.getPlayer().jump();
                        if(this.getGameView().isAccelerate())
                            this.getGame().stopAcc(this.gameView);

                        break;
                    case UP: // Up arrow is pressed
                        if(!Game.isStarted)
                        {
                            this.game.getPlayer().onGround(true);
                            Game.isStarted = true;
                        }
                        this.game.getPlayer().jump();
                        if(this.getGameView().isAccelerate())
                            this.getGame().stopAcc(this.gameView);
                        break;
                    case ESCAPE: // Escape key is pressed
                        if(thread != null) thread.shutdown();
                        javafx.application.Platform.exit();
                        break;
                    case T: // T key is pressed... used for debug
                        debug();
                        break;
                }
            });

        // When keys are released
        this.gameView.getScene().setOnKeyReleased(e -> {
            switch(e.getCode())
            {
                case LEFT: // Left arrow is released
                    this.game.getPlayer().setLeft(false);
                    break;
                case RIGHT: // Right arrow is released
                    this.game.getPlayer().setRight(false);
                    break;
                case SPACE: // Space key is released
                    this.game.getPlayer().setJumping(false);
                    break;
                case ESCAPE: // Escape key is released
                    javafx.application.Platform.exit();
                    break;
                case T:
                    break;
            }
        });
    }

    // Game getter
    public Game getGame()
    {
        return this.game;
    }

    // GameView getter
    public GameView getGameView()
    {
        return this.gameView;
    }
}
