package model;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import view.GameView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Game
{

    // Attributes
    private List<Platform> platforms = new ArrayList<>();
    private List<Bubble> bubbles = new ArrayList<>();
    private Jellyfish player;
    private Platform lastPlat;
    private boolean debug;
    public static boolean isStarted = false;

    // Constructor
    public Game()
    {
        this.player = new Jellyfish((GameView.WIDTH / 2) - (50 / 2),
                GameView.HEIGHT - 50);
        initPlatforms();
    }

    // Bubbles that go out of the screen get deleted from memory
    public void clearBubblesMemory(List<Bubble> list)
    {
        List<Bubble> deleted = new ArrayList<>();
        for(int i = 0; i < list.size(); i++)
            if(list.get(i).y > 0)
                deleted.add(list.get(i));

        list.remove(deleted);
    }

    // Platforms that go out of the screen get deleted from memory
    public void clearPlatformsMemory(List<Platform> list, double offsetY)
    {
        List<Platform> deleted = new ArrayList<>();
        for(int i = 0; i < list.size(); i++)
            if((list.get(i).y - offsetY) > GameView.HEIGHT)
                deleted.add(list.get(i));

        list.remove(deleted);
    }

    public List<Platform> getPlatforms() { return this.platforms; } // Platform getter

    public Jellyfish getPlayer() { return this.player; } // Jellyfish (player) getter

    // TODO: explain
    public void setDebug(boolean b) { this.debug = b; }

    public void restart()
    {
        isStarted = false;
        this.player.reset((GameView.WIDTH / 2) - (50 / 2), GameView.HEIGHT - 50); // Reset player position
        this.player.setDead(false);
        platforms = new ArrayList<>();
        debug = false;
        this.initPlatforms(); // Init new platforms
    }

    // Make the 3 bubble groups
    public void sendBubble()
    {
        int i = 0;

        while(i < 4) // Make 3 groups
        {
            double baseX = new Random().nextInt(GameView.WIDTH + 1); // Random x pos
            for(int j = 0; j < 6; j++)
            {
                int sign = new Random().nextInt((2-1) + 1) + 1; // Random sign (1: +, 2: -)

                double x = (sign == 1) ? (baseX + 20) : (baseX - 20);
                double y = GameView.HEIGHT - 40;
                bubbles.add(new Bubble(x, y));
            }
            i++;
        }
    }

    // We initialize the first platforms
    public void initPlatforms()
    {
        Platform current;
        double size = Math.round((GameView.HEIGHT)/90);

        for (int i = (int)(size - 1); i >= 0; i--)
        {
            current = new Platform(Math.random() * GameView.WIDTH, (double) i / size * GameView.HEIGHT, getNextPlateform());
            current.initXValuePlatform();
            platforms.add(current);
            lastPlat = current;
        }
    }

    // We get the next platform type randomly according to given instructions
    public PlatformType getNextPlateform()
    {
        Random rand;
        PlatformType type = null;

        // No 2 consecutive reds
        if(platforms.size() != 0 && lastPlat.getType().equals(PlatformType.RED))
        {
            rand = new Random();
            int n = rand.nextInt((3 - 1) + 1) + 1;
            switch (n)
            {
                case 1: type = PlatformType.ORANGE; break;
                case 2: type = PlatformType.GREEN; break;
                case 3: type = PlatformType.YELLOW; break;
            }
        }
        else // given instructions ... %s
        {
            rand = new Random();
            int pourcent = rand.nextInt(100);

            if(pourcent >= 0 && pourcent <= 5) type = PlatformType.RED;
            else if(pourcent > 5 && pourcent <= 10) type = PlatformType.YELLOW;
            else if(pourcent > 10 && pourcent <= 20) type = PlatformType.GREEN;
            else if(pourcent > 20) type = PlatformType.ORANGE;
        }
        return type; // return type for next platform
    }

    // Update game part
    public void update(double dt, double offsetY, GameView view)
    {
        // If player loses
        if (this.player.y > GameView.HEIGHT)
        {
            //TODO Fall & loose
            System.out.println("DEEEAD!");
        }
        else
        {
            this.player.onGround(false);
            this.player.update(dt, offsetY); // update jelly
            for (Platform p : platforms)
            {
                double x = getPlayer().y + getPlayer().height - (p.y-offsetY);
                if(x > -1 && x < 1)
                {
                    this.player.onGround(true);
                }
                p.update(dt, offsetY);// update platforms

                // what happens when there's a collision with an orange platform
                if(p.getType().equals(PlatformType.ORANGE))
                {
                    if(this.player.testPlatformCollision(p, offsetY))
                    {
                        player.setY(p.getY() - offsetY - 50);
                        if(p.debug && !p.getDrawDebug()) p.setDrawDebug(true);
                    }
                    else if(p.getDrawDebug())
                        p.setDrawDebug(false);
                }
                // what happens when there's a collision with a red platform
                else if(p.getType().equals(PlatformType.RED))
                {
                    if(this.player.testCollisionRed(p, offsetY))
                    {
                        if(p.debug && !p.getDrawDebug()) p.setDrawDebug(true);
                    }
                    else if(p.getDrawDebug())
                        p.setDrawDebug(false);
                }
                // what happens when there's a collision with a green platform
                else if(p.getType().equals(PlatformType.GREEN))
                {
                    if (this.player.testCollisionGreen(p, offsetY))
                    {
                        if (this.player.vy > -100) { this.player.vy = 100; }

                        if(p.debug && !p.getDrawDebug()) p.setDrawDebug(true);
                    }
                    else if(p.getDrawDebug())
                        p.setDrawDebug(false);
                }
                // what happens when there's a collision with a yellow platform
                else if(p.getType().equals(PlatformType.YELLOW))
                {
                    if(this.player.testPlatformCollision(p, offsetY))
                    {
                        if(!view.isAccelerate())
                        {
                            view.setVy(view.getVy()*2);
                            view.setAccelerate(true, p);
                        }

                        if(p.debug && !p.getDrawDebug()) p.setDrawDebug(true);
                        else p.setDrawDebug(false);
                    }
                    else if(p.getDrawDebug())
                        p.setDrawDebug(false);
                }
                // what happens otherwise
                else
                    if(view.isAccelerate())
                        stopAcc(view);
            }

            // Get the new platforms when going up
            if(platforms.get(platforms.size()-1).y - offsetY > 100)
            {
                platforms.add(new Platform(Math.random() * GameView.WIDTH, (platforms.get(platforms.size()-1).y) - 100, getNextPlateform()));
            }

            // Delete unused platform from memory
            clearPlatformsMemory(platforms, offsetY);
            clearBubblesMemory(bubbles);

            // Screen collision
            this.player.testBorderCollision();
        }
    }

    // TODO: explain
    public void stopAcc(GameView view)
    {
        view.setAccelerate(false, null);
        view.setVy(view.getVy()/2);
    }

    // Updates the bubbles
    public void updateBubbles(double dt, double offsetY)
    {
        // Bubbles
        if(bubbles.size() == 0) return;
        for(int i = 0; i < bubbles.size(); i++)
            bubbles.get(i).update(dt, offsetY);
    }

    // Draws the bubbles
    public void drawBubbles(GraphicsContext context, double offsetY)
    {
        // Bubbles
        if(bubbles.size() == 0) return;
        for(int i = 0; i < bubbles.size(); i++)
            bubbles.get(i).draw(context, offsetY);
    }

    // Draws the player (jellyfish), the platforms, debug and score
    public void draw(GraphicsContext context, double offsetY)
    {
        this.player.draw(context, offsetY);
        for (Platform p : platforms)
            p.draw(context, offsetY);

        // Debug text
        if(debug)
        {
            context.setFont(Font.font("Verdana", 12));
            context.setFill(Color.WHITE);
            context.fillText("Position = (" + Math.round(this.player.x) + ", " + -Math.round((this.player.y + this.player.height) - GameView.HEIGHT) + ")", 5, 15);
            context.fillText("v = (" + Math.round(this.player.vx) + ", " + Math.round(this.player.vy) + ")", 5, 30);
            context.fillText("a = (" + Math.round(this.player.ax) + ", " + -Math.round(this.player.ay) + ")", 5, 45);
            context.fillText("Touche le sol : " + (player.isOnGround() ? "oui" : "non"), 5, 60);
        }
        else
            for(int i = 15; i < 61; i +=  15)
                context.fillText("", 5, i); // Remove text if debug is false

        // Score
        context.setFill(Color.WHITE);
        context.setFont(Font.font("Verdana", 24));
        context.fillText(Math.round(Math.abs(offsetY)) + "m", (GameView.WIDTH/2)-30, 45, 60);
    }
}