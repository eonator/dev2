package model;

// TODO: explain
@FunctionalInterface
public interface EntityDeadEvent
{
    void execute(Game game);
}
