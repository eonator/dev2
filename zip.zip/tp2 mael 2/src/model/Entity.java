package model;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import view.GameView;

public abstract class Entity
{
    // Attributes
    protected double width, height;
    protected double x, y;

    protected double vx, vy;
    protected double ax, ay;

    protected boolean left = false, right = false, jumping = false, onGround = false, debug = false, dead = false;

    protected Color color;

    /**
     * Update pos & velocity
     * @param dt time out since last update()
     */
    public void update(double dt, double offsetY)
    {
        vx += dt * ax;
        vy += dt * ay;

        x += dt * vx;
        y += dt * vy;

        if (x + width > GameView.WIDTH) x = GameView.WIDTH - width; // right limit borne
        if(x < 0) x = 0; // left limit borne
    }

    // Setters
    public void setLeft(boolean b) { left = b; }
    public void setRight(boolean b) { right = b; }
    public void setJumping(boolean b) { jumping = b; }
    public void setDebug(boolean b) { debug = b; }

    // Y getter
    public double getY() { return this.y; }

    // draw for children
    public abstract void draw(GraphicsContext context, double offsetY);
}
